"""Draws the system diagram (system_diagram.png) and writes risk_table.csv."""
import csv
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, ax = plt.subplots(figsize=(13, 6.2)); ax.set_xlim(0, 13); ax.set_ylim(0, 6.2); ax.axis("off")

def zone(x, y, w, h, label, color):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05", fc=color, ec="#555", ls="--", lw=1, alpha=.35))
    ax.text(x + w / 2, y + h - 0.2, label, ha="center", va="top", fontsize=9, style="italic", color="#333")

def box(x, y, w, h, title, sub, color):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.04", fc=color, ec="#222", lw=1.3))
    ax.text(x + w / 2, y + h - 0.22, title, ha="center", va="top", fontsize=10, weight="bold")
    ax.text(x + w / 2, y + h - 0.6, sub, ha="center", va="top", fontsize=8)

def arrow(x1, y1, x2, y2, label, ly=0.2):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=14, lw=1.6, color="#1f4e79"))
    ax.text((x1 + x2) / 2, (y1 + y2) / 2 + ly, label, ha="center", fontsize=7.5, color="#1f4e79")

zone(0.1, 0.3, 3.3, 5.5, "ZONE 1: Classrooms (IoT VLAN)", "#cfe8ff")
zone(3.7, 0.3, 3.2, 5.5, "ZONE 2: Campus server room", "#ffe9b3")
zone(7.2, 0.3, 5.7, 5.5, "ZONE 3: Admin & student-team network (role-based access)", "#d5f5d0")

box(0.35, 3.6, 2.8, 1.5, "Sensor node (simulated)", "ESP32 + SCD41 (CO2/T/RH)\n+ PMS5003 (PM2.5)\nunique device ID + cert", "#ffffff")
box(0.35, 1.2, 2.8, 1.5, "Wokwi / Python simulator", "Generates synthetic readings\nNo real devices or people", "#fff3f3")
box(4.0, 3.4, 2.6, 1.8, "MQTT broker", "Mosquitto-style\nTLS :8883, auth + ACLs\ncampus/<block>/<room>/air/#", "#ffffff")
box(4.0, 1.0, 2.6, 1.7, "Ingest + validation", "Subscriber: range, spike,\nstuck-sensor checks\nSchema check on payload", "#ffffff")
box(7.5, 3.4, 2.4, 1.8, "Time-series store", "Retention: 90 days raw\nAggregates kept longer\nNo personal data", "#ffffff")
box(7.5, 1.0, 2.4, 1.7, "Daily summary job", "daily_summary.py\nMarkdown report", "#ffffff")
box(10.3, 2.2, 2.4, 2.0, "Dashboard + alerts", "Admin: all rooms\nStudent team: read-only\nRoom-level only", "#ffffff")

arrow(3.15, 4.3, 4.0, 4.3, "MQTT/TLS\nQoS 1", 0.25)
arrow(3.15, 1.95, 3.9, 3.7, "publishes", -0.4)
arrow(5.3, 3.4, 5.3, 2.7, "subscribe", 0.0)
arrow(6.6, 1.85, 7.5, 3.6, "clean data", -0.3)
arrow(6.6, 4.3, 7.5, 4.3, "", 0.2)
arrow(8.7, 3.4, 8.7, 2.7, "read", 0.0)
arrow(9.9, 4.3, 10.3, 3.6, "", 0.2)
arrow(9.9, 1.85, 10.3, 2.6, "", 0.2)
ax.text(6.5, 0.05, "Dashed boxes = trust boundaries. Every crossing is authenticated and encrypted. All data in this project is SIMULATED.",
        ha="center", fontsize=8.5, weight="bold")
fig.suptitle("Smart-Campus Air Quality Monitoring - System Architecture", fontsize=13, weight="bold", y=0.98)
fig.savefig("system_diagram.png", dpi=170, bbox_inches="tight")

RISKS = [
 ("R1","Default / weak device credentials","Sensor node","Attacker logs into device or broker","High","Unique per-device credentials or certs; no shared passwords; disable defaults","OWASP IoT Top 10 2018: I1 Weak, Guessable, or Hardcoded Passwords; I9 Insecure Default Settings"),
 ("R2","Unencrypted MQTT (port 1883)","Network / broker","Eavesdropping, tampering with readings","High","TLS on 8883; reject plain connections on campus broker","OWASP IoT 2018: I7 Insecure Data Transfer and Storage; MQTT spec security section"),
 ("R3","Over-broad topic access (# wildcard)","Broker","One compromised node reads/writes every topic","High","ACLs: each device may publish only to its own topic","OWASP IoT 2018: I3 Insecure Ecosystem Interfaces; broker (e.g. Mosquitto) ACL docs"),
 ("R4","Forged or malformed sensor data","Ingest","False alarms or hidden real problems","Medium","Schema + range + spike + stuck checks; signed or authenticated publishers","NIST IR 8228 (data protection risk area); OWASP IoT 2018: I7"),
 ("R5","Outdated firmware / no update path","Sensor node","Known vulnerabilities stay open","High","Signed OTA updates; inventory with firmware versions","OWASP IoT 2018: I4 Lack of Secure Update Mechanism, I5 Insecure or Outdated Components; NIST IR 8259 Rev.1"),
 ("R6","Exposed management interfaces","Broker / dashboard","Remote takeover","High","No public exposure; VPN/campus network only; MFA for admins","OWASP IoT 2018: I2 Insecure Network Services, I3 Insecure Ecosystem Interfaces"),
 ("R7","Denial of service (flooding broker)","Broker","Monitoring goes dark","Medium","Rate limits, connection quotas, monitoring of message rates; device inventory","OWASP IoT 2018: I8 Lack of Device Management; broker docs"),
 ("R8","Privacy creep: occupancy inferred from CO2/motion","Data store / dashboard","Students tracked or surveilled","Medium-High","Room-level only; no IDs; aggregate; retention limit; publish a data notice; no per-person analytics","OWASP IoT 2018: I6 Insufficient Privacy Protection; NIST IR 8228; India DPDP Act 2023 (student to check applicability)"),
 ("R9","Insecure data retention and backups","Data store","Leak of historical data","Medium","Retention policy, encryption at rest, access logging","NIST IR 8228"),
 ("R10","Supply-chain risk and physical tampering","Sensor node","Backdoored devices","Medium","Buy from known vendors; record device provenance; physical tamper protection","OWASP IoT 2018: I5, I10 Lack of Physical Hardening; NIST SP 800-213"),
 ("R11","Excess privileges for student teams","Dashboard","Accidental or deliberate changes to alerts","Medium","Read-only roles for students; admin actions logged","NIST IR 8228"),
 ("R12","Testing against live systems","Process","Disruption or legal exposure","High","Simulation only; written permission before any real test; no live-device attacks","Course ethics rule; CFAA/IT Act principles (check local law)"),
]
with open("risk_table.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["ID","Risk","Component","Impact","Severity","Mitigation","Reference to verify"]); w.writerows(RISKS)
print("diagram + risk table written")
