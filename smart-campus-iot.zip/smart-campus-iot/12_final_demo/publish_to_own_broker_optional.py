"""
OPTIONAL: replay simulated messages to a broker YOU run on your own laptop (e.g. Mosquitto on localhost).
Default is a dry run. Never point this at a college or public broker. Needs: pip install paho-mqtt
  python publish_to_own_broker_optional.py --send --host localhost --port 1883   (use 8883 + TLS in any real setup)
"""
import argparse, json, pathlib, time
ap = argparse.ArgumentParser(); ap.add_argument("--send", action="store_true"); ap.add_argument("--host", default="localhost")
ap.add_argument("--port", type=int, default=1883); ap.add_argument("--limit", type=int, default=20); a = ap.parse_args()
if a.host not in ("localhost", "127.0.0.1"):
    raise SystemExit("Refusing: only localhost brokers you own are allowed in this project (ethics rule).")
path = pathlib.Path(__file__).resolve().parent.parent / "04_simulation/out/mqtt_messages.jsonl"
client = None
if a.send:
    import paho.mqtt.client as mqtt
    client = mqtt.Client(); client.connect(a.host, a.port); client.loop_start()
for i, line in enumerate(open(path)):
    if i >= a.limit: break
    m = json.loads(line)
    if client: client.publish(m["topic"], json.dumps(m["payload"]), qos=m["qos"])
    else: print("DRY RUN", m["topic"], m["payload"])
    time.sleep(0.05)
