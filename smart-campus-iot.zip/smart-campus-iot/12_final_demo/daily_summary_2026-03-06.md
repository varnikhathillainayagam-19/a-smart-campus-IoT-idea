# Smart-Campus Air Quality - Daily Summary (2026-03-06)
_Source: SIMULATED data. No real people or devices._

| Room | Mean CO2 | Peak CO2 | % class hours > 1000 ppm | Mean PM2.5 | Peak PM2.5 | Data issues |
|---|---|---|---|---|---|---|
| LAB-3 | 906 | 2157 | 91% | 22 | 34 | 1 missing, 0 spikes, 0 stuck |
| LH-101 | 913 | 2218 | 89% | 23 | 35 | 6 missing, 0 spikes, 0 stuck |
| LH-102 | 1261 | 4001 | 99% | 23 | 34 | 2 missing, 0 spikes, 24 stuck |
| LIB-RR | 603 | 1050 | 13% | 22 | 35 | 1 missing, 0 spikes, 0 stuck |

## Recommended actions
- **LAB-3**: CO2 above 1000 ppm for 91% of class hours - check ventilation/windows, consider smaller group or breaks.
- **LH-101**: CO2 above 1000 ppm for 89% of class hours - check ventilation/windows, consider smaller group or breaks.
- **LH-102**: CO2 above 1000 ppm for 99% of class hours - check ventilation/windows, consider smaller group or breaks.
- **LH-102**: sensor looked stuck (24 readings) - schedule a sensor check.

_Rules are simple screening thresholds for a student prototype, not medical or regulatory advice. India's NAAQS PM2.5 value is a 24-hour average, so this alert is not a compliance test._