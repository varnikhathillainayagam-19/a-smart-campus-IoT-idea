# Smart-Campus Air Quality - Daily Summary (2026-03-04)
_Source: SIMULATED data. No real people or devices._

| Room | Mean CO2 | Peak CO2 | % class hours > 1000 ppm | Mean PM2.5 | Peak PM2.5 | Data issues |
|---|---|---|---|---|---|---|
| LAB-3 | 916 | 2225 | 91% | 23 | 34 | 4 missing, 0 spikes, 0 stuck |
| LH-101 | 904 | 2202 | 89% | 23 | 33 | 4 missing, 1 spikes, 0 stuck |
| LH-102 | 1481 | 4113 | 99% | 23 | 34 | 0 missing, 0 spikes, 0 stuck |
| LIB-RR | 605 | 1050 | 16% | 23 | 35 | 3 missing, 0 spikes, 0 stuck |

## Recommended actions
- **LAB-3**: CO2 above 1000 ppm for 91% of class hours - check ventilation/windows, consider smaller group or breaks.
- **LH-101**: CO2 above 1000 ppm for 89% of class hours - check ventilation/windows, consider smaller group or breaks.
- **LH-102**: CO2 above 1000 ppm for 99% of class hours - check ventilation/windows, consider smaller group or breaks.

_Rules are simple screening thresholds for a student prototype, not medical or regulatory advice. India's NAAQS PM2.5 value is a 24-hour average, so this alert is not a compliance test._