"""
One-command final demo (all SIMULATED):
  1) generate 7 days of sensor data + charts
  2) replay a few MQTT-style messages (dry run, nothing leaves your computer)
  3) run the validation + daily summary
Run from this folder:  python run_demo.py
"""
import json, subprocess, sys, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
sim, auto = root / "04_simulation", root / "08_automation_script"

print("STEP 1: simulate sensors ->"); subprocess.run([sys.executable, "simulate_air_quality.py"], cwd=sim, check=True)
print("\nSTEP 2: sample MQTT-style messages (dry run)")
with open(sim / "out" / "mqtt_messages.jsonl") as f:
    for _ in range(5):
        m = json.loads(f.readline()); print(f"  PUBLISH {m['topic']}  qos={m['qos']}  {m['payload']}")
print("\nSTEP 3: validate + daily summary ->")
subprocess.run([sys.executable, "daily_summary.py", "--date", "2026-03-06", "--csv", str(sim / "out" / "readings.csv"), "--outdir", str(root / "12_final_demo")], cwd=auto, check=True)
print("\nCharts are in 04_simulation/out/. Demo complete. Data was simulated only.")
