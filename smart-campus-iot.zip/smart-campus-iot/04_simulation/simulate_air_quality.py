"""
Smart-Campus Air Quality - SIMULATED sensor data generator.
No hardware, no network, no real people: every number is synthetic.

Outputs (in ./out):
  readings.csv       one row per room per 5 minutes (7 days)
  mqtt_messages.jsonl  day-1 sample of the data as MQTT-style topic + JSON payload
  chart_co2_day.png, chart_co2_heatmap.png, chart_pm25.png

Run:  python simulate_air_quality.py
Optional: python simulate_air_quality.py --seed 7 --days 7
"""
import argparse, json, os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---- Room model: volume (m3), air changes per hour, capacity ------------------
ROOMS = {
    "LH-101":  dict(block="A", volume=180, ach=2.5, capacity=60),
    "LH-102":  dict(block="A", volume=180, ach=1.2, capacity=60),  # poorly ventilated
    "LIB-RR":  dict(block="B", volume=400, ach=3.0, capacity=80),
    "LAB-3":   dict(block="C", volume=150, ach=2.0, capacity=40),
}
CO2_OUTDOOR = 420.0        # ppm
CO2_PER_PERSON_LPM = 0.31  # litres CO2 per person per minute (sedentary adult, approx.)
STEP_MIN = 5
CO2_THRESHOLD = 1000       # ppm - common "ventilation is inadequate" rule of thumb
PM25_THRESHOLD = 60        # ug/m3 - 24h Indian NAAQS value; WHO 2021 guideline is much lower (15)

def occupancy(ts, room, cap, rng):
    """Weekday timetable: lectures 9-17h with a 13-14h lunch gap; weekends almost empty."""
    if ts.weekday() >= 5:
        return 0
    h = ts.hour + ts.minute / 60
    if room == "LIB-RR":
        base = 0.15 if 8 <= h < 20 else 0
        base += 0.35 * (11 <= h < 17)
    else:
        in_class = (9 <= h < 13) or (14 <= h < 17)
        base = 0.75 if in_class else 0.0
    n = cap * base * rng.uniform(0.7, 1.1)
    return int(max(0, min(cap, rng.normal(n, cap * 0.03))))

def simulate(days=7, seed=42):
    rng = np.random.default_rng(seed)
    idx = pd.date_range("2026-03-02 00:00", periods=days * 24 * 60 // STEP_MIN, freq=f"{STEP_MIN}min")
    rows = []
    for room, p in ROOMS.items():
        co2 = CO2_OUTDOOR
        pm_in = 20.0
        for ts in idx:
            n = occupancy(ts, room, p["capacity"], rng)
            gen_ppm_min = n * CO2_PER_PERSON_LPM / (p["volume"] * 1000) * 1e6
            k = p["ach"] / 60.0                       # per minute
            # exact solution of dC/dt = g - k(C - Cout) over STEP_MIN minutes
            ceq = CO2_OUTDOOR + gen_ppm_min / k
            co2 = ceq + (co2 - ceq) * np.exp(-k * STEP_MIN)
            # outdoor PM2.5 diurnal pattern + a dust event on day 4 (construction)
            h = ts.hour + ts.minute / 60
            pm_out = 38 + 14 * np.sin((h - 6) / 24 * 2 * np.pi) + rng.normal(0, 3)
            if ts.day == 5 and 10 <= h < 12:
                pm_out += 70
            pm_in += (0.6 * pm_out - pm_in) * 0.15 + rng.normal(0, 1)
            temp = 27 + 2.5 * np.sin((h - 9) / 24 * 2 * np.pi) + (n / p["capacity"]) * 1.2 + rng.normal(0, 0.2)
            hum = 62 - 6 * np.sin((h - 9) / 24 * 2 * np.pi) + rng.normal(0, 1)
            rows.append(dict(timestamp=ts, room=room, block=p["block"],
                             occupancy_count_hidden=n,  # kept ONLY to validate the model (see ethics note)
                             co2_ppm=co2 + rng.normal(0, 8),
                             pm25_ugm3=max(1, pm_in),
                             temp_c=temp, humidity_pct=hum))
    df = pd.DataFrame(rows)

    # ---- Inject realistic faults so the pipeline has something to detect ------
    stuck = (df.room == "LH-102") & (df.timestamp >= "2026-03-06 10:00") & (df.timestamp < "2026-03-06 12:00")
    df.loc[stuck, "co2_ppm"] = df.loc[stuck, "co2_ppm"].iloc[0]               # stuck-at fault
    spike = df.sample(6, random_state=seed).index
    df.loc[spike, "co2_ppm"] += 4000                                            # outlier spikes
    drop = df.sample(frac=0.01, random_state=seed + 1).index
    df.loc[drop, ["co2_ppm", "pm25_ugm3", "temp_c", "humidity_pct"]] = np.nan   # packet loss
    return df.drop(columns=["occupancy_count_hidden"]), df  # public data, internal data

def save(df_public, outdir):
    os.makedirs(outdir, exist_ok=True)
    df = df_public.copy()
    num = df.select_dtypes("number").columns
    df[num] = df[num].round(1)
    df.to_csv(f"{outdir}/readings.csv", index=False)
    with open(f"{outdir}/mqtt_messages.jsonl", "w") as f:
        first_day = df[df.timestamp < df.timestamp.min() + pd.Timedelta(days=1)]  # 1-day sample keeps file small
        for r in first_day.itertuples():
            for metric, unit, val in [("co2", "ppm", r.co2_ppm), ("pm25", "ugm3", r.pm25_ugm3),
                                      ("temp", "c", r.temp_c), ("humidity", "pct", r.humidity_pct)]:
                if pd.isna(val):
                    continue
                msg = {"topic": f"campus/{r.block}/{r.room}/air/{metric}",
                       "payload": {"ts": r.timestamp.isoformat(), "value": float(val), "unit": unit, "device": f"sim-{r.room}"},
                       "qos": 1, "retain": False}
                f.write(json.dumps(msg) + "\n")

def charts(df, outdir):
    df = df.copy()
    day = df[df.timestamp.dt.date == pd.Timestamp("2026-03-04").date()]
    fig, ax = plt.subplots(figsize=(9, 4.5))
    for room, g in day.groupby("room"):
        ax.plot(g.timestamp, g.co2_ppm, label=room, lw=1.6)
    ax.axhline(CO2_THRESHOLD, color="crimson", ls="--", label=f"{CO2_THRESHOLD} ppm guideline")
    ax.set_title("Simulated CO2 by room - Wed 4 Mar 2026"); ax.set_ylabel("CO2 (ppm)"); ax.legend()
    ax.set_xlabel("Time of day (simulated data)")
    fig.autofmt_xdate(); fig.tight_layout(); fig.savefig(f"{outdir}/chart_co2_day.png", dpi=150); plt.close(fig)

    wd = df[(df.timestamp.dt.weekday < 5) & df.co2_ppm.lt(3000)]
    pv = wd.assign(h=wd.timestamp.dt.hour).pivot_table(index="room", columns="h", values="co2_ppm", aggfunc="mean")
    fig, ax = plt.subplots(figsize=(9, 3.6))
    im = ax.imshow(pv.values, aspect="auto", cmap="YlOrRd")
    ax.set_yticks(range(len(pv.index)), pv.index); ax.set_xticks(range(len(pv.columns)), pv.columns)
    ax.set_xlabel("Hour of day"); ax.set_title("Mean weekday CO2 (ppm) by room and hour - simulated")
    fig.colorbar(im, label="ppm"); fig.tight_layout(); fig.savefig(f"{outdir}/chart_co2_heatmap.png", dpi=150); plt.close(fig)

    fig, ax = plt.subplots(figsize=(9, 4))
    for room, g in df.groupby("room"):
        ax.plot(g.timestamp, g.pm25_ugm3.rolling(12, min_periods=1).mean(), label=room, lw=1.2)
    ax.axhline(PM25_THRESHOLD, color="crimson", ls="--", label=f"{PM25_THRESHOLD} ug/m3 threshold")
    ax.set_title("Simulated indoor PM2.5 (1-hour rolling mean) - dust event on Thu 5 Mar"); ax.set_ylabel("ug/m3"); ax.legend(ncol=3)
    fig.autofmt_xdate(); fig.tight_layout(); fig.savefig(f"{outdir}/chart_pm25.png", dpi=150); plt.close(fig)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="out")
    a = ap.parse_args()
    pub, internal = simulate(a.days, a.seed)
    save(pub, a.out)
    charts(pub, a.out)
    print(f"Wrote {len(pub)} rows, charts and MQTT-style messages to ./{a.out}")
