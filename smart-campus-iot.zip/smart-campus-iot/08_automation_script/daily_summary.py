"""
Automation step: turn SIMULATED sensor readings into a plain-language daily summary.

  python daily_summary.py --csv ../04_simulation/out/readings.csv --date 2026-03-04

What it does (all offline):
  1. Validates data  - missing values, impossible values, outlier spikes, stuck sensors
  2. Summarises      - mean/peak CO2, % of class hours above threshold, PM2.5 stats
  3. Recommends      - simple rule-based actions for facilities staff
  4. Writes          - daily_summary_<date>.md  (+ prints it)
Security idea shown here: never trust incoming readings - validate before use.
"""
import argparse, os
import numpy as np
import pandas as pd

CO2_LIMIT, PM25_LIMIT = 1000, 60
VALID = {"co2_ppm": (350, 5000), "pm25_ugm3": (0, 500), "temp_c": (-10, 60), "humidity_pct": (0, 100)}

def validate(df):
    """Return (clean_df, None). Bad values become NaN so they never reach a statistic.
    Per-row flags (f_missing, f_range, f_spike, f_stuck) let us report issues for any single day."""
    df = df.sort_values(["room", "timestamp"]).copy()
    for c in ("f_missing", "f_range", "f_spike", "f_stuck"):
        df[c] = False
    for room, g in df.groupby("room"):
        idx = g.index
        df.loc[idx, "f_missing"] = g[list(VALID)].isna().any(axis=1).values
        for col, (lo, hi) in VALID.items():
            bad = g[col].notna() & ~g[col].between(lo, hi)
            df.loc[idx[bad.values], "f_range"] = True
            df.loc[idx[bad.values], col] = np.nan
        # Hampel-style spike filter on CO2: far from the rolling median of neighbours
        med = df.loc[idx, "co2_ppm"].rolling(7, center=True, min_periods=3).median()
        spike = (df.loc[idx, "co2_ppm"] - med).abs() > 1000
        df.loc[idx, "f_spike"] = spike.values
        df.loc[idx[spike.values], "co2_ppm"] = np.nan
        # stuck sensor: identical CO2 for >= 12 consecutive readings (1 hour)
        run = (g.co2_ppm != g.co2_ppm.shift()).cumsum()
        runlen = g.groupby(run).co2_ppm.transform("size")
        stuck = (runlen >= 12) & g.co2_ppm.notna()
        df.loc[idx, "f_stuck"] = stuck.values
        df.loc[idx[stuck.values], "co2_ppm"] = np.nan
    return df, None

def summarise(df, issues, day):
    d = df[df.timestamp.dt.date == pd.Timestamp(day).date()]
    if d.empty:
        raise SystemExit(f"No readings for {day}")
    hours = d.timestamp.dt.hour
    lecture = d[(hours >= 9) & (hours < 17)] if pd.Timestamp(day).weekday() < 5 else d.iloc[0:0]
    lines = [f"# Smart-Campus Air Quality - Daily Summary ({day})",
             "_Source: SIMULATED data. No real people or devices._", "",
             "| Room | Mean CO2 | Peak CO2 | % class hours > 1000 ppm | Mean PM2.5 | Peak PM2.5 | Data issues |",
             "|---|---|---|---|---|---|---|"]
    actions = []
    for room, g in d.groupby("room"):
        lg = lecture[lecture.room == room]
        pct = 100 * (lg.co2_ppm > CO2_LIMIT).sum() / max(1, lg.co2_ppm.notna().sum()) if len(lg) else float("nan")
        i = dict(missing=int(g.f_missing.sum()), spike=int(g.f_spike.sum()), stuck_steps=int(g.f_stuck.sum()))
        flag = f"{i['missing']} missing, {i['spike']} spikes, {i['stuck_steps']} stuck"
        lines.append(f"| {room} | {g.co2_ppm.mean():.0f} | {g.co2_ppm.max():.0f} | "
                     f"{'n/a' if np.isnan(pct) else f'{pct:.0f}%'} | {g.pm25_ugm3.mean():.0f} | {g.pm25_ugm3.max():.0f} | {flag} |")
        if not np.isnan(pct) and pct > 50:
            actions.append(f"- **{room}**: CO2 above {CO2_LIMIT} ppm for {pct:.0f}% of class hours - check ventilation/windows, consider smaller group or breaks.")
        hourly_peak = g.set_index("timestamp").pm25_ugm3.rolling(12, min_periods=6).mean().max()
        if hourly_peak > PM25_LIMIT:
            actions.append(f"- **{room}**: 1-hour mean PM2.5 reached {hourly_peak:.0f} ug/m3 (screening alert above {PM25_LIMIT}) - check dust sources / filter condition.")
        if i["stuck_steps"] > 0:
            actions.append(f"- **{room}**: sensor looked stuck ({i['stuck_steps']} readings) - schedule a sensor check.")
    lines += ["", "## Recommended actions", *(actions or ["- No action needed today."]), "",
              "_Rules are simple screening thresholds for a student prototype, not medical or regulatory advice. India's NAAQS PM2.5 value is a 24-hour average, so this alert is not a compliance test._"]
    return "\n".join(lines)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="../04_simulation/out/readings.csv")
    ap.add_argument("--date", default="2026-03-04")
    ap.add_argument("--outdir", default=".")
    a = ap.parse_args()
    raw = pd.read_csv(a.csv, parse_dates=["timestamp"])
    clean, issues = validate(raw)
    text = summarise(clean, issues, a.date)
    path = os.path.join(a.outdir, f"daily_summary_{a.date}.md")
    open(path, "w").write(text)
    print(text); print(f"\nSaved to {path}")
