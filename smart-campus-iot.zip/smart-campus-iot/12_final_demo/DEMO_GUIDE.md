# Final Demo Guide (3-4 minutes) - simulated data only

1. **Say the ethics line first:** "Everything you will see is simulated. No real devices, people or campus systems."
2. **Run:** `python run_demo.py` (needs Python 3.10+, numpy, pandas, matplotlib).
3. **Show step 1:** data generated for 4 rooms x 7 days; open `04_simulation/out/chart_co2_day.png`.
4. **Show step 2:** MQTT-style topics such as `campus/A/LH-102/air/co2` (dry run).
5. **Show step 3:** the daily summary table and recommended actions; point out the stuck-sensor warning for LH-102 on 6 Mar.
6. **Open** `05_diagram_and_risk/system_diagram.png` and name two controls (TLS 8883, topic ACLs).
7. **Close:** show `10_Verification_Report.docx` - one outdated reference (NIST IR 8259) caught and fixed.

Optional: run `publish_to_own_broker_optional.py` against a Mosquitto broker on your own laptop only.
Optional: mirror the sensor in Wokwi (ESP32 + simulated sensor) and screenshot it for the report.
