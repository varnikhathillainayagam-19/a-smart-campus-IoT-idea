# Smart-Campus Air Quality - Daily Summary (2026-03-05)
_Source: SIMULATED data. No real people or devices._

| Room | Mean CO2 | Peak CO2 | % class hours > 1000 ppm | Mean PM2.5 | Peak PM2.5 | Data issues |
|---|---|---|---|---|---|---|
| LAB-3 | 917 | 2170 | 91% | 26 | 72 | 6 missing, 0 spikes, 0 stuck |
| LH-101 | 929 | 2233 | 91% | 26 | 73 | 3 missing, 0 spikes, 0 stuck |
| LH-102 | 1483 | 3963 | 99% | 27 | 76 | 2 missing, 1 spikes, 0 stuck |
| LIB-RR | 603 | 1019 | 5% | 26 | 71 | 2 missing, 0 spikes, 0 stuck |

## Recommended actions
- **LAB-3**: CO2 above 1000 ppm for 91% of class hours - check ventilation/windows, consider smaller group or breaks.
- **LAB-3**: 1-hour mean PM2.5 reached 70 ug/m3 (screening alert above 60) - check dust sources / filter condition.
- **LH-101**: CO2 above 1000 ppm for 91% of class hours - check ventilation/windows, consider smaller group or breaks.
- **LH-101**: 1-hour mean PM2.5 reached 70 ug/m3 (screening alert above 60) - check dust sources / filter condition.
- **LH-102**: CO2 above 1000 ppm for 99% of class hours - check ventilation/windows, consider smaller group or breaks.
- **LH-102**: 1-hour mean PM2.5 reached 72 ug/m3 (screening alert above 60) - check dust sources / filter condition.
- **LIB-RR**: 1-hour mean PM2.5 reached 70 ug/m3 (screening alert above 60) - check dust sources / filter condition.

_Rules are simple screening thresholds for a student prototype, not medical or regulatory advice. India's NAAQS PM2.5 value is a 24-hour average, so this alert is not a compliance test._